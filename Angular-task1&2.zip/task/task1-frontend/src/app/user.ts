export class User {
    id: number = 0;
    name: string = " ";
    age: number = 0;
}

