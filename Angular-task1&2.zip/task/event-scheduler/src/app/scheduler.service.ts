import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Event } from './event.model';

@Injectable({
  providedIn: 'root',
})
export class SchedulerService {
  private apiUrl = 'http://localhost:8080/api/v1/events'; // Your Spring Boot API

  constructor(private http: HttpClient) {}

  // Get all events
  getEvents(): Observable<Event[]> {
    return this.http.get<Event[]>(this.apiUrl);
  }

  // Create a new event
  createEvent(event: Event): Observable<Object> {
    return this.http.post(this.apiUrl, event);
  }
}
