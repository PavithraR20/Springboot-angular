// src/app/components/create-event/create-event.component.ts
import { Component } from '@angular/core';
import { SchedulerService } from '../scheduler.service';
import { Event } from '../event.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css'],
})
export class CreateEventComponent {
  event: Event = new Event('', 0, 1);  // Initial empty event

  constructor(private schedulerService: SchedulerService, private router: Router) {}

  // Form submission handler
  onSubmit(): void {
    this.schedulerService.createEvent(this.event).subscribe(
      response => {
        console.log('Event created successfully');
        this.router.navigate(['/events']);  // Navigate back to events list
      },
      error => {
        console.error('Error creating event', error);
      }
    );
  }
}