import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateEventComponent } from './create-event/create-event.component';
import { EventComponent } from './event/event.component';

const routes: Routes = [
  {path:'event',component:EventComponent},
  {path:'create-event',component:CreateEventComponent},
  {path:'',redirectTo:'event',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
