package com.event_schedular.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.event_schedular.entity.Event;
import com.event_schedular.service.SchedulerService;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200") // Allow Angular app to access
@RestController
@RequestMapping("/api/v1")
public class SchedulerController {

    @Autowired
    private SchedulerService schedulerService;

    // Endpoint to add an event
    @PostMapping("/events")
    public boolean addEvent(@RequestBody Event event) {
        return schedulerService.addEvent(event);
    }

    // Endpoint to get all events
    @GetMapping("/events")
    public List<Event> getEvents() {
        return schedulerService.getAllEvents();
    }
}

