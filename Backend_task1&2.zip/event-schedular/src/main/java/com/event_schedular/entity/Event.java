package com.event_schedular.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "event")
public class Event {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Primary key, auto-generated

    private String name; // Event name
    private int startTime; // Start time of the event (0-23)
    private int endTime;   // End time of the event (1-24)

    // Default constructor (required by JPA)
    public Event() {
    }

    // Parameterized constructor to easily create event objects
    public Event(String name, int startTime, int endTime) {
        this.name = name;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    // Getters and setters for the fields
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    // Override toString method for logging and debugging purposes
    @Override
    public String toString() {
        return "Event [id=" + id + ", name=" + name + ", startTime=" + startTime + ", endTime=" + endTime + "]";
    }
}
