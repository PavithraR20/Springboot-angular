package com.event_schedular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventSchedularApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventSchedularApplication.class, args);
	}

}
