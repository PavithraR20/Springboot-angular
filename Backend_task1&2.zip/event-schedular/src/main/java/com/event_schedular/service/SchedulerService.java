package com.event_schedular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.event_schedular.entity.Event;
import com.event_schedular.repository.EventRepository;

@Service
public class SchedulerService {
	
    @Autowired
    private EventRepository eventRepository;

    // Check if the new event overlaps with any existing event
    private boolean hasOverlap(Event newEvent, List<Event> events) {
        for (Event existingEvent : events) {
            if (newEvent.getStartTime() < existingEvent.getEndTime() && newEvent.getEndTime() > existingEvent.getStartTime()) {
                return true;
            }
        }
        return false;
    }

    // Add a new event if it doesn't overlap and if the end time is greater than start time
    public boolean addEvent(Event newEvent) {
        // Check if the end time is smaller than the start time
        if (newEvent.getEndTime() <= newEvent.getStartTime()) {
            return false; // Invalid event time, reject the event
        }

        // Fetch all existing events to check for overlaps
        List<Event> events = eventRepository.findAll();

        // If there's an overlap, reject the event
        if (hasOverlap(newEvent, events)) {
            return false; // Overlap found, reject the event
        } else {
            // No overlap, save the event
            eventRepository.save(newEvent);
            return true;
        }
    }

    // Get all events
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }
}
