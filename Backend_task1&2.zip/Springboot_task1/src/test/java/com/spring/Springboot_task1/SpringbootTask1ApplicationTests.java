package com.spring.Springboot_task1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootTask1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
