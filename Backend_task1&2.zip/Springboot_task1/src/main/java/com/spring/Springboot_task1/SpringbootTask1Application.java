package com.spring.Springboot_task1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootTask1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootTask1Application.class, args);
	}

}
